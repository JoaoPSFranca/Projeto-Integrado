
package br.edu.ifsp.pep.enuns;

public enum StatusPedido {
    pago, preparando, pronto, entregue
}
