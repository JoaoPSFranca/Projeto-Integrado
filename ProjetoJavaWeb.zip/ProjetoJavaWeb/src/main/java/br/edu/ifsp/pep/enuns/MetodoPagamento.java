
package br.edu.ifsp.pep.enuns;


public enum MetodoPagamento {
    debito, credito
}
