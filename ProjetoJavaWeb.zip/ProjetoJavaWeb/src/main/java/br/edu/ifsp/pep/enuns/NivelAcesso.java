package br.edu.ifsp.pep.enuns;


public enum NivelAcesso {
    Cliente, Funcionario, Administrador, Terceiro
}