
package br.edu.ifsp.pep.enuns;


public enum MetodoEntrega {
    retirada, entrega
}
